#include <iostream>
using namespace std;
template <typename T>
class MinHeap
{
private:
    T *heapArray;
    int capacity;
    int size;

public:
    MinHeap(int initialCapacity = 10)
    {
        capacity = initialCapacity;
        size = 0;
        heapArray = new T[capacity];
    }

    ~MinHeap()
    {
        delete[] heapArray;
    }

    MinHeap(const MinHeap &other)
    {
        capacity = other.capacity;
        size = other.size;
        heapArray = new T[capacity];

        for (int i = 0; i < size; i++)
        {
            heapArray[i] = other.heapArray[i];
        }
    }

    void insert(T value)
    {
        if (size == capacity)
        {
            resize();
        }

        heapArray[size] = value;
        heapifyUp(size);
        size++;
    }

    void deleteMin()
    {
        if (size == 0)
            return;

        heapArray[0] = heapArray[size - 1];
        size--;
        heapifyDown(0);
    }
      void print()
    {
        if (size == 0)
        {
            cout << "Heap is empty" << endl;
            return;
        }

        int level = 0;
        int levelNodes = 1;
        int nodesCount = 0;

        for (int i = 0; i < size; i++)
        {
            if (nodesCount == 0)
            {
                for (int j = 0; j < (size - levelNodes) / 2; j++)
                {
                    cout << "  ";
                }
            }

            cout << heapArray[i] << " ";
            nodesCount++;

            if (nodesCount == levelNodes)
            {
                cout << endl;
                level++;
                nodesCount = 0;
                levelNodes = levelNodes * 2;
            }
        }
        cout << endl;
    }

private:
    void heapifyUp(int index)
    {
        while (index > 0)
        {
            int parentIndex = (index - 1) / 2;
            if (heapArray[index] < heapArray[parentIndex])
            {
                swap(heapArray[index], heapArray[parentIndex]);
                index = parentIndex;
            }
            else
            {
                break;
            }
        }
    }

    void heapifyDown(int index)
    {
        while (true)
        {
            int smallest = index;
            int leftChild = 2 * index + 1;
            int rightChild = 2 * index + 2;

            if (leftChild < size && heapArray[leftChild] < heapArray[smallest])
            {
                smallest = leftChild;
            }

            if (rightChild < size && heapArray[rightChild] < heapArray[smallest])
            {
                smallest = rightChild;
            }

            if (smallest == index)
            {
                break;
            }

            swap(heapArray[index], heapArray[smallest]);
            index = smallest;
        }
    }

    void resize()
    {
        capacity *= 2;
        T *newArray = new T[capacity];
        for (int i = 0; i < size; i++)
        {
            newArray[i] = heapArray[i];
        }
        delete[] heapArray;
        heapArray = newArray;
    }
};

int main()
{
    MinHeap<int> heap;
    heap.insert(5);
    heap.insert(3);
    heap.insert(7);
    heap.insert(1);
    heap.insert(4);
    heap.insert(6);

    cout << "Original Heap:" << endl;
    heap.print();

    heap.deleteMin();
    cout << "\nAfter deleting minimum element:" << endl;
    heap.print();

    return 0;
}