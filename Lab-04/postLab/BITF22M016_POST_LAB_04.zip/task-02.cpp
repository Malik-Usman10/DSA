#include <cstdio>
#include <iostream>
#include <stack>
using namespace std;

bool isOperator(char c) 
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

int getPrecedence(char c) 
{
    if (c == '^') return 3;
    else if (c == '*' || c == '/') return 2;
    else if (c == '+' || c == '-') return 1;
    else return -1;
}

string infixToPostfix(string infix) 
{
    stack<char> s;
    string postfix;
    
    for (int i = 0; i < infix.length(); i++) 
    {
        if (isalnum(infix[i])) 
        {
            postfix += infix[i];
        }
        else if (infix[i] == '(') 
        {
            s.push(infix[i]);
        }
        else if (infix[i] == ')') 
        {
            while (!s.empty() && s.top() != '(') 
            {
                postfix += s.top();
                s.pop();
            }
            if (!s.empty()) s.pop();
        }
        else if (isOperator(infix[i])) 
        {
            while (!s.empty() && getPrecedence(infix[i]) <= getPrecedence(s.top())) 
            {
                postfix += s.top();
                s.pop();
            }
            s.push(infix[i]);
        }
    }
    
    while (!s.empty()) 
    {
        postfix += s.top();
        s.pop();
    }
    
    return postfix;
}

int main() 
{
    string infix;
    cout << "Enter infix expression: ";
    getline(cin, infix);
    
    string postfix = infixToPostfix(infix);
    
    cout << "Infix expression: " << infix << endl;
    cout << "Postfix expression: " << postfix << endl;
    
    return 0;
}
