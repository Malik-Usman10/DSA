#include <iostream>
#include <stack>
#include <algorithm>
#include <string>
using namespace std;

bool isOperator(char c) 
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

int getPrecedence(char c) 
{
    if (c == '^') return 3;
    else if (c == '*' || c == '/') return 2;
    else if (c == '+' || c == '-') return 1;
    else return -1;
}

string infixToPrefix(string infix) 
{
    reverse(infix.begin(), infix.end());
    
    for (int i = 0; i < infix.length(); i++) 
    {
        if (infix[i] == '(') infix[i] = ')';
        else if (infix[i] == ')') infix[i] = '(';
    }
    
    stack<char> s;
    string prefix;
    
    for (int i = 0; i < infix.length(); i++) 
    {
        if (isalnum(infix[i])) 
        {
            prefix += infix[i];
        }
        else if (infix[i] == '(') 
        {
            s.push(infix[i]);
        }
        else if (infix[i] == ')') 
        {
            while (!s.empty() && s.top() != '(') 
            {
                prefix += s.top();
                s.pop();
            }
            if (!s.empty()) s.pop();
        }
        else if (isOperator(infix[i])) 
        {
            while (!s.empty() && getPrecedence(infix[i]) <= getPrecedence(s.top())) 
            {
                prefix += s.top();
                s.pop();
            }
            s.push(infix[i]);
        }
    }
    
    while (!s.empty()) 
    {
        prefix += s.top();
        s.pop();
    }
    
    reverse(prefix.begin(), prefix.end());
    return prefix;
}

void generateAssemblyCode(string prefix) 
{
    stack<string> s;
    
    for (int i = 0; i < prefix.length(); i++) 
    {
        if (isalnum(prefix[i])) {
            s.push(string(1, prefix[i]));
        }
        else if (isOperator(prefix[i])) 
        {
            string operand2 = s.top();
            s.pop();
            string operand1 = s.top();
            s.pop();
            
            cout << "LD AX, " << operand1 << endl;
            if (prefix[i] == '+') cout << "ADD AX, " << operand2 << endl;
            else if (prefix[i] == '-') cout << "SUB AX, " << operand2 << endl;
            else if (prefix[i] == '*') cout << "MUL AX, " << operand2 << endl;
            else if (prefix[i] == '/') cout << "DIV AX, " << operand2 << endl;
            else if (prefix[i] == '^') cout << "MUL AX, AX" << endl;
            
            s.push("AX");
        }
    }
}

int main() 
{
    string infix;
    cout << "Enter infix expression: ";
    getline(cin, infix);
    
    string prefix = infixToPrefix(infix);
    
    cout << "Infix expression: " << infix << endl;
    cout << "Prefix expression: " << prefix << endl;
    
    cout << "Assembly code:" << endl;
    generateAssemblyCode(prefix);
    
    return 0;
}
